// ! Dont change this code
const {
  fetchProductsData,
  setProductsCards,
  convertToRupiah,
  countDiscount,
} = require("../src/index.js");
const cartData = require("../src/data/cart.js");


describe('Product API Testing', () => {
  // Uji Kasus 1: should return product data with id 1
  test('should return product data with id 1', async () => {
    const productData = await fetchProductsData(1);
    expect(productData.id).toBe(1);
    expect(productData.title).toBe("iPhone 9");
  });

  // Uji Kasus 2: should check products.length with limit
  test('should check products.length with limit', async () => {
    const productData = await fetchProductsData(); 
    const productsCards = setProductsCards(productsData.products);
    const limit = productsData.limit;
    expect(productsCards.length).toBe(limit);
  });

  // Uji Kasus 3: should convert price from dollars to rupiah correctly
  test("should validate product discount calculation", () => {
    const price = 100;
    const discountPercentage = 10;
    const discountedPrice = countDiscount(price, discountPercentage);
    expect(discountedPrice).toBe(90);
  });
});

// Asyncronous Testing
// https://jestjs.io/docs/asynchronous


// Mocking
// https://jestjs.io/docs/mock-functions

const { fetchCartsData } = require("../src/dataService");

jest.mock("../src/dataService", () => {
  const originalModule = jest.requireActual("../src/dataService");
  return {
    ...originalModule,
    __esModule: true,
    fetchCartsData: jest.fn(),
  };
});

// Setup & Teardown
// https://jestjs.io/docs/setup-teardown

describe("Cart API Testing", () => {
  // Test case 1
 
  //Pertama, fungsi fetchCartsData dimock dengan menggunakan fungsi jest.fn(). Mock ini akan mengembalikan data palsu dari keranjang yang diambil dari variabel cartData.carts.
  //Kemudian, fungsi fetchCartsData() dipanggil dengan mock yang telah dibuat. Fungsi ini akan mengembalikan data palsu dari keranjang.
  //Selanjutnya, total item dalam keranjang dihitung dengan menggunakan fungsi reduce(). Fungsi ini akan mengurangi jumlah item dalam keranjang dan mengembalikan totalnya.
  //Terakhir, total item yang dihitung dibandingkan dengan total yang diharapkan dari variabel cartData.total. Jika kedua total tersebut sama, maka test case ini akan lulus.

  test("should compare total cart items with length of fetched data", async () => {
    fetchCartsData.mockResolvedValue(cartData.carts);
    const cartsData = await fetchCartsData();
    const totalItems = cartsData.length;
    const expectedTotal = cartData.total;
    expect(totalItems).toBe(expectedTotal);
  });

  // Test case 2
//Mendefinisikan Test Case:
//Memalsukan Hasil fetchCartsData:
//Memanggil fetchCartsData dan Menunggu Hasilnya:
//Menghitung Total Panjang Carts Data:
//Membandingkan Total Panjang dengan Nilai yang Diharapkan:

  test("should compare total length of carts data with total", async () => {
    fetchCartsData.mockResolvedValue([
      { id: 1, productId: 1, quantity: 1 },
      { id: 2, productId: 2, quantity: 2 },
    ]);
    const cartsData = await fetchCartsData();
    const totalLength = cartsData.reduce((acc, cart) => acc + cart.quantity, 0);
    expect(totalLength).toBe(3);
  });
});

// Setup & Teardown
// https://jestjs.io/docs/setup-teardown

let productsData; // Variabel untuk menyimpan data produk dari API

// Fetch data produk sebelum menjalankan test suite
beforeAll(async () => {
  productsData = await fetchProductsData();
});

describe("Product Utility Testing", () => {
  describe("convertToRupiah", () => {
    // Test case 1
    // memastikan bahwa fungsi convertToRupiah dapat mengonversi nilai 80 dolar 
    // dengan benar menjadi format mata uang Rupiah yang diharapkan, dan hasilnya berupa string.
    test("should convert 100 dollars into rupiah", () => {
      const priceInRupiah = convertToRupiah(80);
      expect(priceInRupiah).toMatch(/Rp\s1\.543\.600,\d{2}/);
      expect(typeof priceInRupiah).toBe("string");
    });

    // Test case 2
    //Test case pertama memastikan fungsi konversi mata uang bekerja dengan benar.
    //Test case kedua belum lengkap dan perlu diisi dengan kode untuk menguji perhitungan diskon.
    test("should convert 1000 dollars into rupiah", () => {
      const priceInRupiah = convertToRupiah(2000);
      expect(priceInRupiah).toMatch(/Rp\s15\.436\.000,\d{2}/);
    });
  });

  test("should calculate discount correctly", () => {
    // Test case 1
    // Test case ini menguji fungsi countDiscount 
    // dengan memberikan harga awal sebesar 130,000 dan persentase diskon sebesar 20%.
    const discountedPrice1 = countDiscount(130000, 20);
    expect(discountedPrice1).toBe(80000);

    // Test case 2
    // Test case ini menguji fungsi countDiscount 
    // untuk memastikan bahwa perhitungan harga diskon dilakukan dengan benar.
    const discountedPrice2 = countDiscount(75000, 10);
    expect(discountedPrice2).toBe(67500);
  });

  describe("setProductsCards", () => {
    test("it should return an array of products with specific keys", () => {
      const productsCards = setProductsCards(productsData.products);
      const firstProductKeys = Object.keys(productsCards[0]);
      const expectedKeys = ["price", "after_discount", "image"];
      expect(firstProductKeys).toEqual(expect.arrayContaining(expectedKeys));
    });
  });
});